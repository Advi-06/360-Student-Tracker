import Link from 'next/link'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { BookOpen } from 'lucide-react'

export default function FAQPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <BookOpen className="h-6 w-6" />
          <span className="sr-only">360° Student Growth Tracker</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/">
            Home
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/about">
            About
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/features">
            Features
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="max-w-3xl mx-auto space-y-8">
          <h1 className="text-3xl font-bold text-center">Frequently Asked Questions</h1>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>What is the 360° Student Growth Tracker?</AccordionTrigger>
              <AccordionContent>
                The 360° Student Growth Tracker is a comprehensive tool designed to monitor and support students' academic, social, and emotional development. It provides insights for students, parents, and teachers to foster holistic growth.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>How does the app ensure student privacy?</AccordionTrigger>
              <AccordionContent>
                We take privacy very seriously. All student data is encrypted and stored securely. Access is strictly limited to authorized users, and we comply with all relevant data protection regulations.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>Can parents access their child's information?</AccordionTrigger>
              <AccordionContent>
                Yes, parents have access to a dedicated portal where they can view their child's progress, receive updates, and access recommendations to support their child's growth.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger>How often is student data updated?</AccordionTrigger>
              <AccordionContent>
                Student data is updated in real-time as teachers input information and students complete self-assessments. However, comprehensive reports are typically generated on a weekly or monthly basis, depending on school preferences.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-5">
              <AccordionTrigger>Is the app suitable for all grade levels?</AccordionTrigger>
              <AccordionContent>
                Yes, the 360° Student Growth Tracker is designed to be adaptable for all grade levels, from elementary through high school. The interface and assessments are tailored to be age-appropriate.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 360° Student Growth Tracker. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}

