import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { BookOpen, Users, Brain, ChevronDown } from 'lucide-react'
import Image from 'next/image'

export default function FeaturesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center">
        <Link className="flex items-center justify-center" href="/">
          <BookOpen className="h-6 w-6" />
          <span className="sr-only">360° Student Growth Tracker</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/">
            Home
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/about">
            About
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/contact">
            Contact
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-8">Our Features</h1>
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <BookOpen className="h-8 w-8 text-blue-500" />
                  <h2 className="text-2xl font-bold">Student Dashboard</h2>
                </div>
                <p className="text-gray-500">
                  A comprehensive view of academic progress, social growth, and emotional well-being. Students can track their development across all areas in one intuitive interface.
                </p>
                <Image
                  alt="Student Dashboard"
                  className="rounded-lg object-cover"
                  height="300"
                  src="/placeholder.svg"
                  style={{
                    aspectRatio: "16/9",
                    objectFit: "cover",
                  }}
                  width="600"
                />
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Users className="h-8 w-8 text-green-500" />
                  <h2 className="text-2xl font-bold">Parental Engagement Portal</h2>
                </div>
                <p className="text-gray-500">
                  Keep parents informed and involved with real-time updates on their child's progress. Features include progress alerts and personalized recommendations.
                </p>
                <Image
                  alt="Parental Portal"
                  className="rounded-lg object-cover"
                  height="300"
                  src="/placeholder.svg"
                  style={{
                    aspectRatio: "16/9",
                    objectFit: "cover",
                  }}
                  width="600"
                />
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Brain className="h-8 w-8 text-purple-500" />
                  <h2 className="text-2xl font-bold">Self-Assessment Tool</h2>
                </div>
                <p className="text-gray-500">
                  Empower students to reflect on their own progress with interactive surveys and goal-setting interfaces. Promotes self-awareness and personal growth.
                </p>
                <Image
                  alt="Self-Assessment Tool"
                  className="rounded-lg object-cover"
                  height="300"
                  src="/placeholder.svg"
                  style={{
                    aspectRatio: "16/9",
                    objectFit: "cover",
                  }}
                  width="600"
                />
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <ChevronDown className="h-8 w-8 text-orange-500" />
                  <h2 className="text-2xl font-bold">Teacher Insights</h2>
                </div>
                <p className="text-gray-500">
                  Provide educators with valuable data and analytics to support personalized learning. Includes student profiles with comprehensive progress reports.
                </p>
                <Image
                  alt="Teacher Insights"
                  className="rounded-lg object-cover"
                  height="300"
                  src="/placeholder.svg"
                  style={{
                    aspectRatio: "16/9",
                    objectFit: "cover",
                  }}
                  width="600"
                />
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 360° Student Growth Tracker. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}

