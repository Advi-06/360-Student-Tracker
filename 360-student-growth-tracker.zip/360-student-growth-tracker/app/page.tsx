import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowRight, BookOpen, Users, Brain, ChevronDown } from 'lucide-react'
import Image from 'next/image'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center">
        <Link className="flex items-center justify-center" href="#">
          <BookOpen className="h-6 w-6" />
          <span className="sr-only">360° Student Growth Tracker</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Features
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            About
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Contact
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Login
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-r from-blue-500 to-green-500">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-white">
                  Empowering Student Growth in Every Dimension
                </h1>
                <p className="mx-auto max-w-[700px] text-white md:text-xl">
                  Track academic, emotional, and social progress effortlessly.
                </p>
              </div>
              <div className="space-x-4">
                <Button asChild>
                  <Link href="#learn-more">Learn More</Link>
                </Button>
                <Button asChild variant="secondary">
                  <Link href="#get-started">Get Started</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        <section id="learn-more" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-8">Key Features</h2>
            <div className="grid gap-6 lg:grid-cols-4 lg:gap-12">
              <div className="flex flex-col items-center space-y-2 border-gray-800 p-4 rounded-lg">
                <BookOpen className="h-12 w-12 text-blue-500" />
                <h3 className="text-xl font-bold">Student Dashboard</h3>
                <p className="text-sm text-gray-500 text-center">Comprehensive view of academic, social, and emotional progress.</p>
              </div>
              <div className="flex flex-col items-center space-y-2 border-gray-800 p-4 rounded-lg">
                <Users className="h-12 w-12 text-green-500" />
                <h3 className="text-xl font-bold">Parental Portal</h3>
                <p className="text-sm text-gray-500 text-center">Stay connected with your child's growth journey.</p>
              </div>
              <div className="flex flex-col items-center space-y-2 border-gray-800 p-4 rounded-lg">
                <Brain className="h-12 w-12 text-purple-500" />
                <h3 className="text-xl font-bold">Self-Assessment Tool</h3>
                <p className="text-sm text-gray-500 text-center">Empower students to reflect on their own progress.</p>
              </div>
              <div className="flex flex-col items-center space-y-2 border-gray-800 p-4 rounded-lg">
                <ChevronDown className="h-12 w-12 text-orange-500" />
                <h3 className="text-xl font-bold">Teacher Insights</h3>
                <p className="text-sm text-gray-500 text-center">Valuable data to support personalized learning.</p>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-8">What Our Users Say</h2>
            <div className="grid gap-6 lg:grid-cols-3 lg:gap-12">
              <div className="flex flex-col items-center space-y-4 text-center">
                <Image
                  alt="User"
                  className="rounded-full"
                  height="100"
                  src="/placeholder.svg"
                  style={{
                    aspectRatio: "100/100",
                    objectFit: "cover",
                  }}
                  width="100"
                />
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Sarah Johnson</h3>
                  <p className="text-sm text-gray-500">"This app has transformed how I track my students' progress. It's comprehensive and intuitive!"</p>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <Image
                  alt="User"
                  className="rounded-full"
                  height="100"
                  src="/placeholder.svg"
                  style={{
                    aspectRatio: "100/100",
                    objectFit: "cover",
                  }}
                  width="100"
                />
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Michael Lee</h3>
                  <p className="text-sm text-gray-500">"As a parent, I feel more connected to my child's education than ever before. Highly recommended!"</p>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <Image
                  alt="User"
                  className="rounded-full"
                  height="100"
                  src="/placeholder.svg"
                  style={{
                    aspectRatio: "100/100",
                    objectFit: "cover",
                  }}
                  width="100"
                />
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Emily Chen</h3>
                  <p className="text-sm text-gray-500">"The self-assessment tools have really helped me understand my strengths and areas for improvement."</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 360° Student Growth Tracker. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}

