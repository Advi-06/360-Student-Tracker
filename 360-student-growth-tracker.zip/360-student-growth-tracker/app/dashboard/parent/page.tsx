import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { BookOpen, Brain, Users, Bell } from 'lucide-react'

export default function ParentDashboard() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <BookOpen className="h-6 w-6" />
          <span className="sr-only">360° Student Growth Tracker</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Profile
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Settings
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Logout
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <h1 className="text-2xl font-bold mb-4">Parent Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Academic Progress</h2>
            <Progress value={75} className="mb-2" />
            <p className="text-sm text-gray-500">75% complete</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Social Growth</h2>
            <Progress value={60} className="mb-2" />
            <p className="text-sm text-gray-500">60% progress</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Emotional Well-being</h2>
            <Progress value={80} className="mb-2" />
            <p className="text-sm text-gray-500">80% positive</p>
          </div>
        </div>
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Recommendations</h2>
          <ul className="space-y-2">
            <li className="flex items-center">
              <Brain className="mr-2 h-5 w-5" />
              <span>Encourage more reading time to improve comprehension skills</span>
            </li>
            <li className="flex items-center">
              <Users className="mr-2 h-5 w-5" />
              <span>Consider enrolling in a team sport to enhance social skills</span>
            </li>
            <li className="flex items-center">
              <Bell className="mr-2 h-5 w-5" />
              <span>Schedule a parent-teacher conference to discuss progress</span>
            </li>
          </ul>
        </div>
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Recent Notifications</h2>
          <ul className="space-y-2">
            <li className="p-2 bg-blue-100 rounded">
              <span className="font-semibold">Math Test Result:</span> Your child scored 85% on the recent algebra test.
            </li>
            <li className="p-2 bg-green-100 rounded">
              <span className="font-semibold">Social Milestone:</span> Your child has shown improvement in group activities.
            </li>
            <li className="p-2 bg-yellow-100 rounded">
              <span className="font-semibold">Upcoming Event:</span> School science fair next Friday.
            </li>
          </ul>
        </div>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 360° Student Growth Tracker. All rights reserved.</p>
      </footer>
    </div>
  )
}

