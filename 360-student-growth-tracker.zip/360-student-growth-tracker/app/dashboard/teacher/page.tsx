import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { BookOpen, Brain, Users, Search } from 'lucide-react'
import { Input } from '@/components/ui/input'

export default function TeacherDashboard() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <BookOpen className="h-6 w-6" />
          <span className="sr-only">360° Student Growth Tracker</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Profile
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Settings
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Logout
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <h1 className="text-2xl font-bold mb-4">Teacher Dashboard</h1>
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
            <Input placeholder="Search students" className="pl-8" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Class Average - Academic</h2>
            <Progress value={70} className="mb-2" />
            <p className="text-sm text-gray-500">70% overall progress</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Class Average - Social</h2>
            <Progress value={65} className="mb-2" />
            <p className="text-sm text-gray-500">65% overall progress</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Class Average - Emotional</h2>
            <Progress value={75} className="mb-2" />
            <p className="text-sm text-gray-500">75% overall well-being</p>
          </div>
        </div>
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Student List</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Academic Progress</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Social Growth</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Emotional Well-being</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">John Doe</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Progress value={80} className="w-full" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Progress value={70} className="w-full" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Progress value={90} className="w-full" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Button size="sm">View Profile</Button>
                  </td>
                </tr>
                {/* Add more student rows here */}
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 360° Student Growth Tracker. All rights reserved.</p>
      </footer>
    </div>
  )
}

