import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { BookOpen, Brain, Users } from 'lucide-react'

export default function StudentDashboard() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <BookOpen className="h-6 w-6" />
          <span className="sr-only">360° Student Growth Tracker</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Profile
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Settings
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Logout
          </Link>
        </nav>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <h1 className="text-2xl font-bold mb-4">Student Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Academic Progress</h2>
            <Progress value={75} className="mb-2" />
            <p className="text-sm text-gray-500">75% complete</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Social Growth</h2>
            <Progress value={60} className="mb-2" />
            <p className="text-sm text-gray-500">60% progress</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Emotional Well-being</h2>
            <Progress value={80} className="mb-2" />
            <p className="text-sm text-gray-500">80% positive</p>
          </div>
        </div>
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Daily Check-In</h2>
          <Button>Start Self-Assessment</Button>
        </div>
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Upcoming Tasks</h2>
          <ul className="space-y-2">
            <li className="flex items-center">
              <input type="checkbox" className="mr-2" />
              <span>Complete Math Assignment</span>
            </li>
            <li className="flex items-center">
              <input type="checkbox" className="mr-2" />
              <span>Read Chapter 5 of History Book</span>
            </li>
            <li className="flex items-center">
              <input type="checkbox" className="mr-2" />
              <span>Prepare for Science Presentation</span>
            </li>
          </ul>
        </div>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 360° Student Growth Tracker. All rights reserved.</p>
      </footer>
    </div>
  )
}

